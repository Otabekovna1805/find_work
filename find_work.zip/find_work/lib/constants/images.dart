sealed class Images {
  /// #signIn
  static const lottieSignIn = "assets/lotties/sign_in.json";

  /// #intro
  static const logoWhite = "assets/logos/white.png";

  /// #signUp
  static const signUp = "assets/lotties/sign_up.json";

  /// #vacancyOrResume
  

}