import 'package:find_work/pages/vacancy_or_resume.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            onPressed: () {},
            icon: PopupMenuButton<int>(
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 1,
                  child: Row(
                    children: [
                      IconButton(onPressed: (){}, icon: const Icon(CupertinoIcons.bookmark,),),
                      Text("Saved", style: TextStyle(fontSize: 18.sp),)
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 2,
                  child: Row(
                    children: [
                      IconButton(onPressed: (){}, icon: const Icon(Icons.sunny,),),
                      Text("Mode", style: TextStyle(fontSize: 18.sp),)
                    ],
                  ),
                ),
              ],
            ))
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const VacancyOrResume()));
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
