package uz.otabekovna.find_work

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
